# Project 5 — Blog CMS (PHP + Laravel)

## Stack
| Service     | Image                | Port       |
|-------------|----------------------|------------|
| Laravel     | php:8.3-fpm-alpine   | 9000 (FPM) |
| Nginx       | nginx:alpine         | 80         |
| MySQL       | mysql:8              | 3306       |
| Redis       | redis:7-alpine       | 6379       |
| MinIO       | minio/minio          | 9000, 9001 |
| Queue Worker| (same build as app)  | -          |

## Docker Compose Concepts Covered
- php-fpm + nginx split (two containers serving one app)
- Separate `queue` service running same image with different command
- Named volume `vendor_data` to avoid bind-mount overwriting vendor/
- MinIO as S3-compatible local file storage
- MySQL healthcheck with mysqladmin
- Redis for cache, sessions AND queue

## Quick Start
```bash
# 1. Start everything
docker compose up --build

# 2. Run migrations (first time)
docker compose exec app php artisan migrate

# 3. Generate app key
docker compose exec app php artisan key:generate

# 4. Create MinIO bucket
#    Open http://localhost:9001
#    login: minioadmin / minioadmin
#    Create bucket: blog-media (set public)

# 5. Open the blog
open http://localhost:80

# 6. Watch queue worker
docker compose logs -f queue

# 7. Teardown
docker compose down
docker compose down -v   # removes volumes too
```

## Project Structure
```
project5-php-laravel-blog/
├── app/
│   ├── Http/Controllers/PostController.php
│   ├── Jobs/SendPostNotification.php
│   └── Models/Post.php
├── database/migrations/
│   └── 2024_01_01_000000_create_posts_table.php
├── resources/views/
│   ├── layouts/app.blade.php
│   └── posts/index.blade.php / show.blade.php
├── routes/
│   ├── web.php / api.php / console.php
├── config/filesystems.php
├── nginx/default.conf
├── public/index.php
├── bootstrap/app.php
├── composer.json
├── Dockerfile
├── docker-compose.yml
├── .env
└── README.md
```

## Key Learning Points
1. php-fpm handles PHP execution; nginx handles HTTP — two containers, one app
2. `vendor_data` named volume prevents host bind mount from hiding the installed vendor/ folder
3. Queue worker is same Docker image, different `command:` — no second Dockerfile needed
4. MinIO is a drop-in S3 replacement — same Laravel S3 driver, no AWS account needed
5. Redis handles cache + sessions + queue simultaneously via different DB indexes
