<?php

namespace App\Http\Controllers;

use App\Jobs\SendPostNotification;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PostController extends Controller
{
    public function index()
    {
        $posts = Cache::remember('posts.published', 60, function () {
            return Post::published()->paginate(10);
        });

        return view('posts.index', compact('posts'));
    }

    public function show(Post $post)
    {
        return view('posts.show', compact('post'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'      => 'required|string|max:255',
            'body'       => 'required|string',
            'excerpt'    => 'nullable|string|max:500',
            'cover'      => 'nullable|image|max:2048',
            'published'  => 'boolean',
        ]);

        $data['slug'] = Str::slug($data['title']);

        if ($request->hasFile('cover')) {
            $data['cover_image'] = $request->file('cover')
                ->store('covers', 'minio');
        }

        if ($data['published'] ?? false) {
            $data['published_at'] = now();
        }

        $post = Post::create($data);

        // Dispatch to Redis queue
        SendPostNotification::dispatch($post);

        Cache::forget('posts.published');

        return redirect()->route('posts.show', $post->slug);
    }

    public function destroy(Post $post)
    {
        if ($post->cover_image) {
            Storage::disk('minio')->delete($post->cover_image);
        }
        $post->delete();
        Cache::forget('posts.published');
        return redirect()->route('posts.index');
    }
}
