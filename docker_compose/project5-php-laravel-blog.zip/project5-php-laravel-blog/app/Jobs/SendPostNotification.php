<?php

namespace App\Jobs;

use App\Models\Post;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendPostNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 10;

    public function __construct(public readonly Post $post) {}

    public function handle(): void
    {
        // Simulate sending email/push notification
        sleep(1);
        Log::info("Notification sent for post: {$this->post->title}");
    }

    public function failed(\Throwable $e): void
    {
        Log::error("Failed to notify for post {$this->post->id}: {$e->getMessage()}");
    }
}
