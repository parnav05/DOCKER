@extends('layouts.app')

@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h1>All Posts</h1>
</div>

<div class="card" style="margin-bottom:24px;">
    <h2 style="margin-bottom:12px; font-size:16px;">New Post</h2>
    <form action="{{ route('posts.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <label>Title</label>
        <input type="text" name="title" required placeholder="Post title..." />
        <label>Excerpt</label>
        <input type="text" name="excerpt" placeholder="Short description..." />
        <label>Body</label>
        <textarea name="body" rows="5" required placeholder="Post content..."></textarea>
        <label>Cover Image</label>
        <input type="file" name="cover" accept="image/*" />
        <label style="display:flex; gap:8px; align-items:center; margin-bottom:12px;">
            <input type="checkbox" name="published" value="1" style="width:auto;"> Publish immediately
        </label>
        <button class="btn" type="submit">Create Post</button>
    </form>
</div>

@forelse($posts as $post)
<div class="card">
    <h2 style="margin-bottom:6px;"><a href="{{ route('posts.show', $post->slug) }}" style="text-decoration:none;color:#1d4ed8;">{{ $post->title }}</a></h2>
    <p style="font-size:13px; color:#6b7280; margin-bottom:8px;">{{ $post->published_at?->diffForHumans() }}</p>
    <p style="margin-bottom:12px;">{{ $post->excerpt }}</p>
    <form action="{{ route('posts.destroy', $post) }}" method="POST" style="display:inline;">
        @csrf @method('DELETE')
        <button class="btn btn-red" type="submit" style="font-size:12px; padding:6px 12px;">Delete</button>
    </form>
</div>
@empty
<div class="card"><p style="color:#6b7280;">No published posts yet. Create one above!</p></div>
@endforelse

{{ $posts->links() }}
@endsection
