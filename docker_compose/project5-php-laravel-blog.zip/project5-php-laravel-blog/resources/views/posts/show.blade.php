@extends('layouts.app')

@section('content')
<div style="margin-bottom:12px;"><a href="{{ route('posts.index') }}" style="color:#1d4ed8;">← Back</a></div>
<div class="card">
    @if($post->cover_image)
    <img src="{{ Storage::disk('minio')->url($post->cover_image) }}" style="width:100%;border-radius:8px;margin-bottom:16px;" />
    @endif
    <h1>{{ $post->title }}</h1>
    <p style="font-size:13px;color:#6b7280;margin:8px 0 16px;">{{ $post->published_at?->format('M d, Y') }}</p>
    <div style="line-height:1.8;">{{ $post->body }}</div>
</div>
@endsection
