<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>{{ config('app.name') }}</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: sans-serif; background: #f9fafb; color: #1f2937; }
        .container { max-width: 800px; margin: 0 auto; padding: 24px 16px; }
        nav { background: #1d4ed8; padding: 14px 24px; display: flex; gap: 16px; align-items: center; }
        nav a { color: #fff; text-decoration: none; font-weight: 500; }
        h1 { font-size: 24px; margin-bottom: 16px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; margin-bottom: 16px; box-shadow: 0 1px 4px rgba(0,0,0,.08); }
        .btn { display: inline-block; padding: 9px 18px; border-radius: 8px; background: #1d4ed8; color: #fff; border: none; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-red { background: #dc2626; }
        input, textarea { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; margin-bottom: 12px; }
        label { font-size: 13px; font-weight: 500; display: block; margin-bottom: 4px; }
    </style>
</head>
<body>
<nav>
    <a href="{{ route('posts.index') }}">📝 Laravel Blog</a>
    <a href="{{ route('posts.index') }}">All Posts</a>
</nav>
<div class="container">
    @yield('content')
</div>
</body>
</html>
