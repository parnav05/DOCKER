<?php

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/posts', function () {
    return Post::published()->paginate(10);
});

Route::get('/posts/{post:slug}', function (Post $post) {
    return $post;
});

Route::get('/health', function () {
    return response()->json(['status' => 'ok', 'time' => now()]);
});
