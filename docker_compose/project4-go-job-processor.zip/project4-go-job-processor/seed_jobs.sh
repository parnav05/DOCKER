#!/bin/bash
# Push sample jobs into the Redis stream for testing
echo "Seeding 30 test jobs..."

for i in $(seq 1 10); do
  docker exec job_redis redis-cli XADD jobs "*" type email payload "{\"to\":\"user${i}@example.com\",\"subject\":\"Hello ${i}\"}"
  docker exec job_redis redis-cli XADD jobs "*" type resize_image payload "{\"url\":\"https://example.com/img${i}.jpg\"}"
  docker exec job_redis redis-cli XADD jobs "*" type report payload "{\"report_id\":${i}}"
done

echo "Done. Watch the worker logs with: docker compose logs -f worker"
