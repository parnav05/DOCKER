package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"sync"
	"syscall"

	"github.com/example/job-processor/internal/job"
	"github.com/example/job-processor/internal/store"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
)

func env(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func main() {
	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	opt, err := redis.ParseURL(env("REDIS_URL", "redis://localhost:6379"))
	if err != nil {
		log.Fatal("redis parse:", err)
	}
	rdb := redis.NewClient(opt)
	defer rdb.Close()

	s, err := store.New(ctx, env("DATABASE_URL", "postgres://jobuser:jobpass@localhost:5432/jobsdb?sslmode=disable"))
	if err != nil {
		log.Fatal("store:", err)
	}
	defer s.Close()

	proc := job.New(rdb, s, env("REDIS_STREAM", "jobs"), env("REDIS_GROUP", "workers"), env("REDIS_CONSUMER", "worker-1"))
	if err := proc.Init(ctx); err != nil {
		log.Fatal("init stream:", err)
	}

	metricsPort := env("METRICS_PORT", "2112")
	go func() {
		http.Handle("/metrics", promhttp.Handler())
		log.Printf("Metrics on :%s/metrics", metricsPort)
		log.Fatal(http.ListenAndServe(":"+metricsPort, nil))
	}()

	numWorkers, _ := strconv.Atoi(env("WORKERS", "3"))
	var wg sync.WaitGroup
	for i := 0; i < numWorkers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			proc.Run(ctx)
		}()
	}

	log.Printf("Started %d workers. Waiting for jobs...", numWorkers)
	<-ctx.Done()
	log.Println("Shutting down...")
	wg.Wait()
}
