package job

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"time"

	"github.com/example/job-processor/internal/metrics"
	"github.com/example/job-processor/internal/store"
	"github.com/redis/go-redis/v9"
)

type Processor struct {
	rdb      *redis.Client
	store    *store.Store
	stream   string
	group    string
	consumer string
}

func New(rdb *redis.Client, s *store.Store, stream, group, consumer string) *Processor {
	return &Processor{rdb: rdb, store: s, stream: stream, group: group, consumer: consumer}
}

func (p *Processor) Init(ctx context.Context) error {
	err := p.rdb.XGroupCreateMkStream(ctx, p.stream, p.group, "$").Err()
	if err != nil && err.Error() != "BUSYGROUP Consumer Group name already exists" {
		return fmt.Errorf("create group: %w", err)
	}
	return nil
}

func (p *Processor) Run(ctx context.Context) {
	log.Printf("Worker started: stream=%s group=%s consumer=%s", p.stream, p.group, p.consumer)
	for {
		select {
		case <-ctx.Done():
			return
		default:
			p.poll(ctx)
		}
	}
}

func (p *Processor) poll(ctx context.Context) {
	result, err := p.rdb.XReadGroup(ctx, &redis.XReadGroupArgs{
		Group: p.group, Consumer: p.consumer,
		Streams: []string{p.stream, ">"},
		Count: 10, Block: 2 * time.Second,
	}).Result()
	if err != nil {
		return
	}
	for _, stream := range result {
		for _, msg := range stream.Messages {
			p.handle(ctx, msg)
		}
	}
	depth, _ := p.rdb.XLen(ctx, p.stream).Result()
	metrics.QueueDepth.Set(float64(depth))
}

func (p *Processor) handle(ctx context.Context, msg redis.XMessage) {
	jobType, _ := msg.Values["type"].(string)
	payloadStr, _ := msg.Values["payload"].(string)
	payload := json.RawMessage(payloadStr)

	start := time.Now()
	result, err := p.process(ctx, jobType, payload)
	duration := time.Since(start).Seconds()
	metrics.JobDuration.WithLabelValues(jobType).Observe(duration)

	if err != nil {
		log.Printf("[FAIL] %s id=%s err=%v", jobType, msg.ID, err)
		metrics.JobsProcessed.WithLabelValues(jobType, "failed").Inc()
		_ = p.store.MarkFailed(ctx, msg.ID, err.Error())
	} else {
		log.Printf("[OK]   %s id=%s dur=%.3fs", jobType, msg.ID, duration)
		metrics.JobsProcessed.WithLabelValues(jobType, "done").Inc()
		_ = p.store.MarkDone(ctx, msg.ID, result)
	}

	p.rdb.XAck(ctx, p.stream, p.group, msg.ID)
	p.store.SaveJob(ctx, msg.ID, jobType, payload)
}

func (p *Processor) process(_ context.Context, jobType string, _ json.RawMessage) (json.RawMessage, error) {
	switch jobType {
	case "email":
		time.Sleep(time.Duration(100+rand.Intn(200)) * time.Millisecond)
		return json.RawMessage(`{"sent": true}`), nil
	case "resize_image":
		time.Sleep(time.Duration(300+rand.Intn(500)) * time.Millisecond)
		return json.RawMessage(`{"width": 800, "height": 600}`), nil
	case "report":
		time.Sleep(time.Duration(500+rand.Intn(1000)) * time.Millisecond)
		return json.RawMessage(`{"rows": 1500}`), nil
	default:
		return nil, fmt.Errorf("unknown job type: %s", jobType)
	}
}
