package store

import (
	"context"
	"encoding/json"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct{ pool *pgxpool.Pool }

func New(ctx context.Context, dsn string) (*Store, error) {
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	return &Store{pool: pool}, nil
}

func (s *Store) SaveJob(ctx context.Context, streamID, jobType string, payload json.RawMessage) error {
	_, err := s.pool.Exec(ctx,
		`INSERT INTO jobs (stream_id, type, payload, status) VALUES ($1,$2,$3,'pending')
		 ON CONFLICT (stream_id) DO NOTHING`,
		streamID, jobType, payload)
	return err
}

func (s *Store) MarkDone(ctx context.Context, streamID string, result json.RawMessage) error {
	now := time.Now()
	_, err := s.pool.Exec(ctx,
		`UPDATE jobs SET status='done', result=$1, processed_at=$2 WHERE stream_id=$3`,
		result, now, streamID)
	return err
}

func (s *Store) MarkFailed(ctx context.Context, streamID string, errMsg string) error {
	now := time.Now()
	_, err := s.pool.Exec(ctx,
		`UPDATE jobs SET status='failed', error=$1, processed_at=$2, retries=retries+1 WHERE stream_id=$3`,
		errMsg, now, streamID)
	return err
}

func (s *Store) Close() { s.pool.Close() }
