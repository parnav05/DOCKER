package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	JobsProcessed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "jobs_processed_total",
		Help: "Total number of jobs processed",
	}, []string{"type", "status"})

	JobDuration = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name:    "job_duration_seconds",
		Help:    "Duration of job processing in seconds",
		Buckets: prometheus.DefBuckets,
	}, []string{"type"})

	QueueDepth = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "job_queue_depth",
		Help: "Current number of pending jobs in the Redis stream",
	})
)
