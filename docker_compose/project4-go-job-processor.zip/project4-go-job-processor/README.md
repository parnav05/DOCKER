# Project 4 — Background Job Processor (Go)

## Stack
| Service    | Image                   | Port |
|------------|-------------------------|------|
| Go Worker  | golang:1.22-alpine      | 2112 (metrics) |
| Redis      | redis:7-alpine          | 6379 |
| PostgreSQL | postgres:16-alpine      | 5432 |
| Prometheus | prom/prometheus         | 9090 |
| Grafana    | grafana/grafana         | 3000 |

## Docker Compose Concepts Covered
- Go multi-stage build → scratch image (~5MB final)
- Redis Streams as a job queue
- Prometheus scraping custom Go metrics
- Grafana datasource + dashboard provisioning via volumes
- Custom bridge network with 5 services

## Quick Start
```bash
docker compose up --build

# Push test jobs
./seed_jobs.sh

# Watch worker process them
docker compose logs -f worker

# Grafana dashboard
open http://localhost:3000
# login: admin / admin

# Prometheus
open http://localhost:9090

docker compose down
```

## Project Structure
```
project4-go-job-processor/
├── cmd/worker/
│   └── main.go               # Entry point, wires everything
├── internal/
│   ├── job/processor.go      # Redis stream consumer + job dispatch
│   ├── store/postgres.go     # Job result persistence
│   └── metrics/prometheus.go # Prometheus counters/histograms
├── prometheus/
│   └── prometheus.yml        # Scrape config
├── grafana/
│   ├── provisioning/         # Auto-provision datasource + dashboard
│   └── dashboards/jobs.json  # Pre-built dashboard
├── init.sql                  # DB schema
├── seed_jobs.sh              # Push test jobs to Redis
├── go.mod
├── Dockerfile
├── docker-compose.yml
├── .env
└── README.md
```

## Key Learning Points
1. Multi-stage Go build → `scratch` image, 5MB vs 800MB dev image
2. Grafana provisioning via volume mounts — dashboard loads on first boot
3. Prometheus scrape target is the worker's `/metrics` endpoint inside the Docker network
4. Redis Streams (`XREADGROUP`) give consumer groups + acknowledgement — reliable queue
