# Project 3 — E-commerce Product API (Java + Spring Boot)

## Stack
| Service    | Image                          | Port |
|------------|--------------------------------|------|
| Spring Boot| eclipse-temurin:21-jre-alpine  | 8080 |
| PostgreSQL | postgres:16-alpine             | 5432 |

## Docker Compose Concepts Covered
- Multi-stage Docker build (Maven build → slim JRE runtime)
- JVM container-aware flags (`UseContainerSupport`)
- Flyway auto-migrations on startup
- Spring profiles via environment variables
- `service_healthy` dependency for startup ordering

## Quick Start
```bash
# Build and start (first build takes ~2-3 min — Maven downloads deps)
docker compose up --build

# API is live at
open http://localhost:8080/api/products

# Health check
curl http://localhost:8080/actuator/health

# Create a product
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Laptop","price":999.99,"stock":10,"sku":"TECH-999"}'

docker compose down
```

## Project Structure
```
project3-java-ecommerce/
├── src/main/java/com/ecommerce/product/
│   ├── ProductApiApplication.java
│   ├── controller/ProductController.java
│   ├── service/ProductService.java
│   ├── repository/ProductRepository.java
│   ├── repository/CategoryRepository.java
│   ├── model/Product.java
│   ├── model/Category.java
│   └── dto/ProductRequest.java / ProductResponse.java
├── src/main/resources/
│   ├── application.yml
│   └── db/migration/
│       ├── V1__init_schema.sql
│       └── V2__seed_data.sql
├── pom.xml
├── Dockerfile
├── docker-compose.yml
├── .env
└── README.md
```

## Key Learning Points
1. Multi-stage build cuts final image from ~600MB to ~120MB
2. Flyway runs migrations automatically — no manual SQL needed
3. `ddl-auto: validate` means Hibernate validates schema but never changes it (Flyway owns migrations)
4. `UseContainerSupport` makes JVM respect Docker memory limits
